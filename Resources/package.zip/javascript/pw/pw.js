//define our proteomics workbench namespace to hold all of our stuff
var pw = {};


